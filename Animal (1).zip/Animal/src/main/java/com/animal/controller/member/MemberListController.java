package com.animal.controller.member;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.animal.controller.SuperClass;
import com.animal.dao.MemberDao;
import com.animal.model.Member;

public class MemberListController extends SuperClass {
	@Override // 회원 목록을 조회합니다.
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		super.doGet(request, response);

		MemberDao dao = new MemberDao();
		List<Member> lists = null;
		try {
			lists = dao.SelectAll();

			request.setAttribute("datalist", lists);

			String gotopage = "member/meList.jsp";
			super.Gotopage(gotopage);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

